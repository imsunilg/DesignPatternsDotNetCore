export const LOGO_URL= "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQq1R0sW84he6t6H9QpnOaqrTsm8cmH1RSr_w&s";
export const CDN_URL="https://media-assets.swiggy.com/swiggy/image/upload/fl_lossy,f_auto,q_auto,w_660/";
// export const RESTAURANT_API_URL = "https://www.swiggy.com/dapi/restaurants/list/v5?lat=19.117505970734232&lng=72.997374124825";
export const RESTAURANT_API_URL = "https://www.swiggy.com/dapi/restaurants/list/v5?lat=19.117505970734232&lng=72.997374124825&is-seo-homepage-enabled=true&page_type=DESKTOP_WEB_LISTING";
export const CORS_URL="https://proxy.cors.sh/";
export const CORS_TOKEN="temp_ff16a5ad3ff6956acfa5a10e4a8341b7";
export const RESTAURANT_MENU_API_URL = "https://www.swiggy.com/dapi/menu/pl?page-type=REGULAR_MENU&complete-menu=true&lat=19.110366882422&lng=73.00358659721493&restaurantId=";