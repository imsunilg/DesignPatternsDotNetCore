import React, { useState, useEffect } from "react";
import RestaurantCard from "./RestaurantCard";
import Shimmer from "./Shimmer";
import { RESTAURANT_API_URL, CORS_URL, CORS_TOKEN } from "../utils/constants";
import { Link } from "react-router-dom";

import { useOnlineStatus } from "../utils/useOnlineStatus";

const Body = () => {
  const [listOfRestaurants, setListOfRestaurants] = useState([]);
  const [MasterlistOfRestaurants, setMasterListOfRestaurants] = useState([]);
  const [searchText, setSearchText] = useState("");

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const data = await fetch(RESTAURANT_API_URL);

    //     const fetchData = async () => {
    //     const data = await fetch(CORS_URL+RESTAURANT_API_URL, {
    //   headers: {
    //   'x-cors-api-key': CORS_TOKEN
    //   }
    // });

    const json = await data.json();
    console.log(json?.data);
    setListOfRestaurants(
      json?.data?.cards[4]?.card?.card?.gridElements?.infoWithStyle
        ?.restaurants || []
    );
    setMasterListOfRestaurants(
      json?.data?.cards[4]?.card?.card?.gridElements?.infoWithStyle
        ?.restaurants || []
    );
  };

  const onlineStatus = useOnlineStatus();
  if (onlineStatus === false) {
    return (
      <h1>
        Look like you're offlice!!! Please check your internet connection...
      </h1>
    );
  }

  // Show shimmer while data is loading

  return listOfRestaurants.length === 0 &&
    MasterlistOfRestaurants.length === 0 ? (
    <Shimmer />
  ) : (
    <div className="body">
      <div className="filter">
        <div className="search">
          <input
            type="text"
            placeholder="Search for restaurants"
            className="search-box"
            value={searchText}
            onChange={(e) => {
              setSearchText(e.target.value);
            }}
          />
          <button
            className="search-btn"
            onClick={() => {
              console.log({ searchText });
              //filter the restaurants based on search text
              const filteredRestaurants = MasterlistOfRestaurants.filter(
                (restaurant) =>
                  restaurant.info.name
                    .toLowerCase()
                    .includes(searchText.toLowerCase())
              );
              setListOfRestaurants(filteredRestaurants);
            }}
          >
            Search
          </button>
        </div>

        <button
          className="filter-btn"
          onClick={() => {
            let filterList = listOfRestaurants.filter(
              (restaurant) => restaurant.info.avgRating > 4.4
            );
            setListOfRestaurants(filterList);
          }}
        >
          Top Rated Restaurants
        </button>
      </div>

      <div className="res-conatainer">
        {listOfRestaurants.map((restaurant, index) => (
          <Link
            to={"/restaurants/" + restaurant.info.id}
            key={restaurant.info.id || index}
          >
            <RestaurantCard
              key={restaurant.info.id || index}
              resData={restaurant}
            />
          </Link>
        ))}
      </div>
    </div>
  );
};

export default Body;
