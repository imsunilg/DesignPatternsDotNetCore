import React, { use } from "react";
import { LOGO_URL } from "../utils/constants";
import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

import { useOnlineStatus } from "../utils/useOnlineStatus";
export const Header = () => {
  const [btnReactName, setBtnReactName] = useState("Login");
  const onlineStatus = useOnlineStatus();
  // if no dependencies are passed, useEffect will run on every render
  // if an empty array is passed, useEffect will run only once after the first render
  // if dependencies are passed, useEffect will run when those dependencies change
  useEffect(() => {
    console.log("useEffect called");
  }, [btnReactName]);

  return (
    <div className="header">
      <div className="logo-container">
        <img className="logo" alt="logo" src={LOGO_URL} />
      </div>
      <div className="nav-items">
        <ul> <li className="nav-item">
          {onlineStatus ? "✅" : "🔴"} {onlineStatus ? "Online" : "Offline"}
          </li>
          <li className="nav-item">
            <Link to="/">Home</Link>
          </li>
          <li className="nav-item">
            <Link to="/About">About Us</Link>
          </li>
          <li className="nav-item">
            <Link to="/Contact">Contact Us</Link>
          </li>
          <li className="nav-item">
            <Link to="/Grocery">Grocery</Link>
          </li>
          
          <li className="nav-item">Cart</li>
          <button
            className="login-btn"
            onClick={() => {
              btnReactName === "Login"
                ? setBtnReactName("Logout")
                : setBtnReactName("Login");
            }}
          >
            {btnReactName}
          </button>
        </ul>
      </div>
    </div>
  );
};

export default Header;
