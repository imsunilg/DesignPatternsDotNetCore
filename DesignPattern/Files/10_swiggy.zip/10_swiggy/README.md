## Coding Assignment:

- `Clean up` your code.
- Create a `Folder Structure` for your app.
- Make `different files` for each Component.
- Create a `config file`.
- Use all types of `import and export`.
- Create a `Restaurant Filter button`
- Use `useState` to create a variable and `bind` it to the `Restaurant Filter Button`.
- Try to make your `Filter Button Work`.

## [Food App Filter Feature](https://food-app-filter-feature-vasu.netlify.app/)

## References:

- [Akshay Saini Code Link](https://bitbucket.org/namastedev/namaste-react-live/src/master/)
/*
 * Header
 *  - logo
 *  - nav items
 * Body
 *  - Search bar
 *  - RestaurantContainer
 *    - RestaurantCard
 *     - Image
 *     - Name of Restaurant,Raiting, Delivery Time,cuisine
 *
 * Footer
 *  - Links
 *  - Copyright
 *  - Address
 *  - Contact
 *  - Social Media Links
 */